# Do Nothing

This Virtual Camera __Body__ algorithm does not move the Virtual Camera; it does not modify its position. Choose this algorithm for static shots or for animating the camera position directly with your custom scripts.

